/*

 Metacube  Assignment 03 

 Dear sir  

 this  is  just  the  for  functionality  check  i will  commit  all  the  changes  after  green  signal  from  your  side  

 Thank You

*/


import java.util.*;
import java.lang.*;
class MC_3 {


 public static int equals( String str1 , String str2 )
  {
     if(str1.length() != str2.length() )
        return 0;

     for( int i=0; i<str1.length(); i++ )
        { 
          if( str1.charAt(i) != str2.charAt(i) )
             return 0;
        }

    return 1;
  }



 public static String reverse( String str1 )
  {
     String str2 = "";

     for( int i=str1.length()-1; i>=0; i-- )
         str2 += String.valueOf(str1.charAt(i) );
        
    return str2;
  }


 public static String Upper_to_Lower( String str1 )
  {
      String str2 ="";

      for( int i=0; i<str1.length(); i++ )
         { 
           int temp = str1.charAt(i);

           if( temp >= 65 && temp <= 90 )
             {
               
                temp += 32;
                 
                
                str1 = str1.substring(0,i) + String.valueOf((char)temp) + str1.substring(i+1);
             }
         }

      return str1;
  }


 public static String Lower_to_Upper( String str1 )
  {
 
      String str2 ="";

      for( int i=0; i<str1.length(); i++ )
         { 
           int temp = str1.charAt(i);

           if( temp >= 97 && temp <= 122 )
             {
               temp -= 32;
               str1 = str1.substring(0,i) +  String.valueOf( (char)temp ) + str1.substring(i+1);
             }
         }

      return str1;
  }






 public static void main(String args[] )
  {
    Scanner s = new Scanner(System.in);
    Scanner s1 = new Scanner(System.in);
    String str1 = s.nextLine();
    String str2 = s1.nextLine();

   System.out.println(Upper_to_Lower(str1) );
   System.out.println(Lower_to_Upper(str2) );

  }
 }


 // This  is  the  other  question  for  the  same  assignment

 
import java.util.*;
 class M3_2
 {

  public static int max_grade( int arr[] )
  {
    int max = arr[0];
 
    for(int i=1; i<arr.length; i++ )
       {
         if( arr[i] > max )
           max = arr[i];         
       }
    return max;
  }


 public static int min_grade( int arr[] )
  {
    int min = arr[0];
 
    for(int i=1; i<arr.length; i++ )
       {
         if( arr[i] < min )
           min = arr[i];         
       }
    return min;
  }

 public static float average_grade( int arr[] )
  {
    float sum = 0;

    for( int i=0; i<arr.length; i++ )
       sum += arr[i];

     return sum/arr.length;
  }

 
 public static float percentage_passed( int arr[] )
  { 
     
     int count = 0;

     for( int i =0; i<arr.length; i++ )
        {
           if( arr[i] >= 40 )
              count++;
        }

     
     return  count / (float) arr.length * 100 ;

     //return (float) (count / arr.length) * 100;
     
  }


 public static void main(String args[])
  {
    Scanner s = new Scanner(System.in);
    int n = s.nextInt();

    int arr[] = new int[n];


    for( int i =0; i<n; i++ )
       arr[i] = s.nextInt();

    System.out.println( max_grade(arr) );
    System.out.println( min_grade(arr) );
    System.out.println( average_grade(arr) );
    System.out.println( percentage_passed(arr) );
  }
  
 }
